var main = function () {
    "use strict";

    window.alert("hello world!");
};

$(document).ready(main);
